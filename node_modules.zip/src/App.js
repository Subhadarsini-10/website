import "./App.css";
import SideMenu from "./component/SideMenu";
import { BrowserRouter, Routes, Route, Switch, Router } from "react-router-dom";

const App = () => {
  return (
      <div className="App">
        <SideMenu />
      </div>
  );
};

export default App;
