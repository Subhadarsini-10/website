import React from "react";

const Lessons = () => {
  return (
    <div>
      <h1>hello</h1>
    </div>
  );
};

export default Lessons;
